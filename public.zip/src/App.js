import Pannel from './components/Pannel';


function App() {
  return (
    <>
    <Pannel />

    </>
  );
}

export default App;

import './Pannel.css'; 
import React, { useState, useRef, useEffect } from 'react';
import { Link } from "react-router-dom";

const MusicPlayer = ({ audioSource, isCurrent, onTogglePlay }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef(null);

  useEffect(() => {
    const audioElement = audioRef.current;

    const updateTime = () => {
      setCurrentTime(audioElement.currentTime);
      setDuration(audioElement.duration);
    };

    audioElement.addEventListener('timeupdate', updateTime);

    return () => {
      audioElement.removeEventListener('timeupdate', updateTime);
    };
  }, []);

  useEffect(() => {
    if (isCurrent) {
      setIsPlaying(true);
      audioRef.current.play();
    } else {
      setIsPlaying(false);
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, [isCurrent]);

  const togglePlayPause = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
    onTogglePlay();
  };

  const handleTimeUpdate = (e) => {
    setCurrentTime(e.target.currentTime);
  };

  const handleSeekBarChange = (e) => {
    const newTime = e.target.value;
    audioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  return (
    <>
      <audio ref={audioRef} src={audioSource} onTimeUpdate={handleTimeUpdate}></audio>
      <div>
      <input
          type="range"
          value={currentTime}
          max={duration}
          onChange={handleSeekBarChange}
        />
        <br />

        <button onClick={togglePlayPause}>
          {isPlaying ? 'Pause' : 'Play'}
        </button>
      </div>
    </>
  );
};

function Pannel() {
  const [currentAudio, setCurrentAudio] = useState(null);

  const handleAudioToggle = (audioSource) => {
    setCurrentAudio(currentAudio === audioSource ? null : audioSource);
  };

  return (
    <>
    <div className="contain">
        <div className="header">
        <header>
        <img src="logo.png" alt='dream'/>
  </header>

  <nav>
    <Link to="/Home">Home</Link>
    <Link to="/Pannel">Browse</Link>
    <Link to="/Contact">Contact</Link>
  </nav>
        </div>
        <br />
        <br />
    <div class="flip">
    <div class="front" style={{backgroundImage: "url(/maxresdefault.jpg)"}}>
       <h1 class="text-shadow">Für Elise</h1>
    </div>
    <div class="back">
       <h2>Für Elise - Reimagined</h2>
       <p>Song by Alexander Joseph</p>
       <br />
       <br />
       <MusicPlayer
            audioSource="reim.mp3"
            isCurrent={currentAudio === "reim.mp3"}
            onTogglePlay={() => handleAudioToggle("reim.mp3")}
          />
    </div>
</div>
<div class="flip">
<div class="front" style={{backgroundImage: "url(/Interstellar.jpg)"}}>
       <h1 class="text-shadow">Interstellar</h1>
    </div>
    <div class="back">
       <h2>Interstellar (Piano)</h2>
       <p>Song by Andy Morris</p>
       <br />
       <br />
       <MusicPlayer
            audioSource="inter.mp3"
            isCurrent={currentAudio === "inter.mp3"}
            onTogglePlay={() => handleAudioToggle("inter.mp3")}
          />
    </div>
</div>
<div class="flip">
<div class="front" style={{backgroundImage: "url(/eye.jpg)"}}>
       <h1 class="text-shadow">Eyes Don't Lie</h1>
    </div>
    <div class="back">
       <h2>Eyes Don't Lie</h2>
       <p>Song by Isabel LaRosa</p>
       <br />
       <br />
       <MusicPlayer
            audioSource="eyes.mp3"
            isCurrent={currentAudio === "eyes.mp3"}
            onTogglePlay={() => handleAudioToggle("eyes.mp3")}
          />
    </div>
</div>

<br />
<br />

<div class="flip flip-vertical">
    <div class="front" style={{backgroundImage: "url(/solas.jpg)"}}>
       <h1 class="text-shadow">SOLAS</h1>
    </div>
    <div class="back">
       <h2>SOLAS</h2>
       <p>Song by Gibran Alcocer</p>
       <br />
       <br />
       <MusicPlayer
            audioSource="solas.mp3"
            isCurrent={currentAudio === "solas.mp3"}
            onTogglePlay={() => handleAudioToggle("solas.mp3")}
          />
    </div>
</div>
<div class="flip flip-vertical">
<div class="front" style={{backgroundImage: "url(/love.jpg)"}}>
       <h1 class="text-shadow">Need A Love</h1>
    </div>
    <div class="back">
       <h2>Need A Love</h2>
       <p>Song by noel.smt</p>
       <br />
       <br />
       <MusicPlayer
            audioSource="love.mp3"
            isCurrent={currentAudio === "love.mp3"}
            onTogglePlay={() => handleAudioToggle("love.mp3")}
          />
    </div>
</div>
<div class="flip flip-vertical">
          <div class="front" style={{ backgroundImage: "url(/fish.png)" }}>
            <h1 class="text-shadow">Swarm of Fish</h1>
          </div>
          <div class="back">
            <h2>Swarm of Fish</h2>
            <p>Song by Pianopassion</p>
            <br />
       <br />
       <MusicPlayer
            audioSource="fish.mp3"
            isCurrent={currentAudio === "fish.mp3"}
            onTogglePlay={() => handleAudioToggle("fish.mp3")}
          />
          </div>
        </div>
    </div>
    </>
  );
}

export default Pannel;

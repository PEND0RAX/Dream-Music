import React, { useState } from 'react';
import './contactus.css';
import { Link } from "react-router-dom";


function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        console.log('Email sent successfully!');
        // Handle success (e.g., show a success message to the user)
      } else {
        console.error('Error sending email');
        // Handle error (e.g., show an error message to the user)
      }
    } catch (error) {
      console.error('Error sending email', error);
    }
  };

  return (
    <>
    <div className="header">
        <header>
        <img src="logo.png" alt='dream' />
  </header>

  <nav>
    <Link to="/Home">Home</Link>
    <Link to="/Pannel">Browse</Link>
    <Link to="/Contact">Contact</Link>
  </nav>
        </div>
    <div className="container">
      <h1 className='head-01'>Contact Us</h1>
      </div>
      <br />
      <br />
      <div className="contact-container">
      <form className="contact-form" onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" name="name" onChange={handleChange} required />
        
        <label>Email:</label>
        <input type="email" name="email" onChange={handleChange} required />
        
        <label>Message:</label>
        <textarea name="message" onChange={handleChange} required />
        
        <button type="submit">Submit</button>
      </form>
    </div>

    </>
  );
}

export default Contact;
